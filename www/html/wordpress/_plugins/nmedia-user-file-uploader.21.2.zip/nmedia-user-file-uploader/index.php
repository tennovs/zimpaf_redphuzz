<?php
/**
 * Silent is golden
 **/