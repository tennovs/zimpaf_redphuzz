<?php 
/*
 * Listing all users with file stats
 */
global $nmfilemanager;


?>
<h4>
	<?php _e("Sync FTP Files", 'nm-filemanager')?>
</h4>
<div id="filemanager-userfiles">

<p>
    <a href="#" id="ftp_post" class="button button-primary">
        <?php _e('Post FTP files', 'nm-filemanager')?>
    </a>
    <span class="nm-ftping-file"></span></p>
</div>