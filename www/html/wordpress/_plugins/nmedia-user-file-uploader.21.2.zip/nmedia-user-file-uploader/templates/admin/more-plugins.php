<?php
/**
 * this template describe how to use this plugin
 * **/
 ?>
 
<div class="wrap">
    
<h3>More Awesome Addons Of File Manager</h3>

    <div class="row">
        <div class="col-md-6">
            <a href="https://najeebmedia.com/wpfm/">
                <img style="width:104%; height:130px" src="<?php echo WPFM_URL.'/images/more-plugins/amazon.jpg'; ?>" alt="">
            </a>
        </div>
         <div class="col-md-6">
            <a href="https://najeebmedia.com/wpfm/">
                <img style="width:104%; height:130px" src="<?php echo WPFM_URL.'/images/more-plugins/BuddyFiles.jpg'; ?>" alt="">
            </a>
        </div>
    </div>
    <div class="row" style="padding-top:10px;">
        <div class="col-md-6">
            <a href="https://najeebmedia.com/wpfm/">
                <img style="width:104%; height:130px" src="<?php echo WPFM_URL.'/images/more-plugins/download-manager.jpg'; ?>" alt="">
            </a>
        </div>
         <div class="col-md-6">
            <a href="https://najeebmedia.com/wpfm/">
                <img style="width:104%; height:130px" src="<?php echo WPFM_URL.'/images/more-plugins/file-revision.jpg'; ?>" alt="">
            </a>
        </div>
    </div>
    <div class="row" style="padding-top:10px;">
        <div class="col-md-6">
            <a href="https://najeebmedia.com/wpfm/">
                <img style="width:104%; height:130px" src="<?php echo WPFM_URL.'/images/more-plugins/table-view.jpg'; ?>" alt="">
            </a>
        </div>
         <div class="col-md-6">
            <a href="https://najeebmedia.com/wpfm/">
                <img style="width:104%; height:130px" src="<?php echo WPFM_URL.'/images/more-plugins/user-specific.jpg'; ?>" alt="">
            </a>
        </div>
    </div>
</div>