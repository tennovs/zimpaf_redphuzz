<?php
/**
 * this template describe how to use this plugin
 * **/
 ?>
 
 <ol>
     <li>Create a new page (better to use full width template)</li>
     <li>Just paste this shorcode: [ffmwp]</li>
     <li>That's it.</li>
 </ol>
 
 <p>Then you can adjust settings as per your need under Tabs on left sides, e.g:</p>
 
<h3>PRO Features</h3>
<ol>
<li>Create Directories</li>
<li>Set Maximum File Upload</li>
<li>Set Limit per User File Count</li>
<li>Set Filesize quota for Roles</li>
<li>Email Notifications Settings</li>
<li>File Rename by Timestamp Prefix</li>
<li>Allow Geusts to Upload</li>
<li>Allow Users to Share File via Email</li>
<li>File Groups</li>
<li>Create Unlimited Download Areas</li>
<li>File Meta - Create Fields and attache with files</li>
<li>Visual Composer Addon</li>
</ol>