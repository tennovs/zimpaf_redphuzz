jQuery(document).ready(function($) {
    $('.multiple-select').select2();
});