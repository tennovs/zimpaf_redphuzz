<?php
/**
 * Maintenance page template
 *
 * @package Welcart
 */

$html = '<div id="maintenance-page">

<div class="post">
<p>' . esc_html__( 'Maintaining now', 'usces' ) . '</p>
<p>' . esc_html__( 'Please wait for a while.', 'usces' ) . '</p>
</div>

</div>';
