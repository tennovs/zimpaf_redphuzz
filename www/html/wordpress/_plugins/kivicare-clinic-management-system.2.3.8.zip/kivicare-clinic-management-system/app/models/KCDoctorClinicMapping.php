<?php


namespace App\models;

use App\baseClasses\KCModel;

class KCDoctorClinicMapping extends KCModel {

	public function __construct()
	{
		parent::__construct('doctor_clinic_mappings');
	}


}