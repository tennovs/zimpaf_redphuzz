<?php
    
?>

<li class="active tab-item" data-check="false">
    <a class="tab-link" href="#clinic" data-iq-toggle="tab" data-iq-tab="prevent" id="clinic-tab">
        <h5>Choose a Clinic</h5>
        <p>Please select a Clinic you want to visit</p>
    </a>
</li>
