<?php

?>

<li class="tab-item" data-check="false">
    <a class="tab-link" href="#detail-info" data-iq-toggle="tab" data-iq-tab="prevent" id="detail-info-tab">
        <h5>User Detail Information</h5>
        <p>Please provide you contact details</p>
    </a>
</li>
