<?php

?>

<li class="tab-item">
    <a class="tab-link" href="#confirm" data-iq-toggle="tab" data-iq-tab="prevent" id="confirm-tab">
        <h5>Confirmation</h5>
        <p>Confirm your booking</p>
    </a>
</li>
