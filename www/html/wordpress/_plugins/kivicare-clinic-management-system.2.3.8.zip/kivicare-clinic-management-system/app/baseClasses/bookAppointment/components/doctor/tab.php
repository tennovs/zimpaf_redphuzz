<?php

?>

<li class="tab-item" data-check="false">
    <a class="tab-link" href="#doctor" data-iq-toggle="tab" data-iq-tab="prevent" id="doctor-tab">
        <h5>Choose Your Doctor</h5>
        <p>pick a specific Doctor to perform your service </p>
    </a>
</li>
