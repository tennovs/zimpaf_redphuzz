<div id="app" data-base-path="<?php echo KIVI_CARE_DIR; ?>">
</div>