=== True Ranker ===
Contributors:
Donate link: https://www.trueranker.com
Tags: SEO, Google position, Google ranking, Rank tracker, SEO tool 
Requires at least: 3.0.1
Tested up to: 5.8
Stable tag: 2.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

SEO Local Rank now is True Ranker! True Ranker checks your Google Serps position in the country, state or city where you want. You can find your competition in each city and improve your SEO strategy in this city.

== Description ==

Now you can enjoy for free with the only SEO App that gives you total control of your geolocated Google results with 100% real accuracy.

With TRUE RANKER we offer real and accurate information about the rankings of your keywords depending on the country, state or city from which the search is made.

Discover how your target keywords behave in the other cities, other platforms give you your global position for each target word so you can not know in what position you are appearing in other cities. With TRUE RANKER, SEO takes a step forward and discover first-hand the evolution of your geolocated keywords in real time.

Have you ever wondered what position your website is in when searching for your keywords from USA, UK, India, New York, London, Dublin or any other city? SEO LOCAL RANK lets you know and track your words so you can choose the best strategy for your business.

We have both free plans for small websites and plans for large sites and agencies.

Local Rank Checker & Tracker Tool.

Because ranking is different from one city to another, we developed local rank checker, a tool which can check the website ranking and show you exactly the position in real time for the targeted locations, either cities or countries. It’s very userful due to its approach, the dynamic keyword tracking which can help you on search engine optimization process and marketing activities.

This tool helps you to check your website ranking as a local user, make you understand the results of your SEO campaign and to identify the way your website is ranking on different search engines. All these obtained data can help you into the keyword prospecting process or gives you the possibility of using them in the development of your marketing strategy.

Discover now the real data.

A few notes about the sections above:

*   "Dashboard" is a summary of the data collected for your project. Keywords positions, competitors, etc.
*   "Upgrade" is to upgrade your plan and get more advantages.
*   "Settings" is the plugin settings.
*   "Help" is a form to get help directly from Seolocalrank Team.
    

== Installation ==

=== From within WordPress ===

1. Visit 'Plugins > Add New'
1. Search for 'True Ranker'
1. Activate True Ranker from your Plugins page.
1. Go to "after activation" below.

=== Manually ===

1. Upload the `seolocalrank` folder to the `/wp-content/plugins/` directory
1. Activate the True Ranker plugin through the 'Plugins' menu in WordPress
1. Go to "after activation" below.
== Frequently Asked Questions ==

=== After activation ===

1. You should get an API Key from trueranker.com. We send you this API Key by email.
1. Copy your API Key and paste it in the text box and click in start button.
1. You're done!

== Frequently Asked Questions ==

You'll find answers to many of your questions on [trueranker.com/en](https://trueranker.com/en).

== Screenshots ==

1. The True Ranker wellcome page
2. This is True Ranker dashboard page
3. This is the page for add new keywords in your project


== Changelog ==

= 2.2.2 =
* Fix some bugs

= 2.1.8 =
* Fix some bugs

= 2.1.8 =
* Add mobile serps tracking


= 2.1.7 =
* Add more info for ever keyword
* Design change

= 2.1.3 =
* Fix some bugs
* Keyword volume, cpc and dificulty 

= 2.0.5 =
* Fix some bugs 

= 2.0 =
* We are change de name and the design of the plugin and we are improve this funcionalities

= 1.0 =
* First version

== Upgrade Notice ==






