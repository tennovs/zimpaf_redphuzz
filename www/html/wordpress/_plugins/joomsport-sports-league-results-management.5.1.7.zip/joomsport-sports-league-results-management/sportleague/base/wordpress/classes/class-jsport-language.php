<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */
class classJsportLanguage
{
    public static function getTranslation($var)
    {
        return __($var,'joomsport-sports-league-results-management');
    }
}
