<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */
class classExtrafieldEditor
{
    public static function getValue($ef)
    {
        return $ef;
    }
}
