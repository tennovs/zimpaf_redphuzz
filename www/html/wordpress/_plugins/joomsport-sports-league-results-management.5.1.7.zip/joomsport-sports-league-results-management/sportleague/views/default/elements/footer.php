<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
wp_register_script( 'lightboxjs-js', JOOMSPORT_LIVE_ASSETS."js/lightbox.js", ['jquery'], NULL, true );
?>


