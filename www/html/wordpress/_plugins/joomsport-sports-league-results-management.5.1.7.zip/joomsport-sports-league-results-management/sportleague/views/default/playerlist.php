<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<div>
    <?php
    require JOOMSPORT_PATH_VIEWS_ELEMENTS.'player-list.php';
    ?>
</div>
