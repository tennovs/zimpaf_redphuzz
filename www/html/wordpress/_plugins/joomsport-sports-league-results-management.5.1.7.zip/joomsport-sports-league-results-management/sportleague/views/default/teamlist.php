<?php
/**
 * WP-JoomSport
 * @author      BearDev
 * @package     JoomSport
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<div>
    <?php
    require_once JOOMSPORT_PATH_VIEWS_ELEMENTS.'team-list.php';
    ?>
</div>
