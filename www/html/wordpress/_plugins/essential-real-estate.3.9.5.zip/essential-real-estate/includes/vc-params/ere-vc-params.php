<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
//selectize
require_once ERE_PLUGIN_DIR . 'includes/vc-params/selectize/class-ere-vc-param-selectize.php';