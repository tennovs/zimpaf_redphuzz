<div class="container-fluid">
	<div class="rezgo-content-row">
		<h1 id="rezgo-about-head"><?php echo $title; ?></h1>
		<div id="rezgo-about-content"><?php echo $site->getPageContent($page); ?></div>
	</div>
</div>