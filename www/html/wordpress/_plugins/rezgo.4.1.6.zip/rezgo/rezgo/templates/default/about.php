<div class="container-fluid rezgo-container">
	<div class="rezgo-content-row">
		<h1 id="rezgo-about-head">About Us</h1>

		<div id="rezgo-about-content"><?php echo $site->getPageContent('aboutus'); ?></div>
	</div>
</div>