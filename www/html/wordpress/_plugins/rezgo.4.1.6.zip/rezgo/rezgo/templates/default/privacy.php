<div class="container-fluid">

  <div class="jumbotron">
    <h2 id="rezgo-terms-head">Privacy Policy</h2>

    <div class="row">
    	<div class="rezgo-page-content">
			<?php echo $site->getPageContent('privacy')?>
      </div>
    </div>

  </div>

</div>
