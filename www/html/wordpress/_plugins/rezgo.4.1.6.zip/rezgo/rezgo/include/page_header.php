<?php
	if (!defined('ABSPATH')) {
		exit;
	}

	require_once('config.rezgo.php');

	require_once('class.rezgo.php');
?>