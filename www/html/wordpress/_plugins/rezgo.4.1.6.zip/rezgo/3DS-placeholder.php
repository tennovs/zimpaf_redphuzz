<?php
    // this file is displayed on the 3DS modal on checkout by default, it is replaced by the posted data
    
    require('rezgo/include/page_header.php');
    
    echo '<!DOCTYPE html><body><br><br><div style="font-family: Arial, Helvetica, sans-serif; text-align: center; font-size: 18px;">Please wait ...</div>';
    
    echo '</body></html>';