<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.

require_once plugin_dir_path( __FILE__ ) .'classes/setup.class.php';
