<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * Deprecated framework functions from past framework versions. You shouldn't use these
 * functions and look for the alternatives instead. The functions will be removed in a later version.
 *
 */
