<?php
/**
* Sample Form Fields
* Field Name = Field Value
* FirstName=first name
* LastName=last name
* Company=abc company
*/
echo $_REQUEST['FirstName']."\n"; // will show "first name"
echo $_REQUEST['LastName']."\n"; // will show "last name"
echo $_REQUEST['Company']."\n"; // will show "abc company"
?>