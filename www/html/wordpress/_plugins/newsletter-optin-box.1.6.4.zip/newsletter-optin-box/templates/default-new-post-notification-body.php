<h1>[[post_title]]</h1>
<p>[[post_excerpt]]</p>
<p>[[read_more_button]]<?php _e( 'Continue Reading', 'newsletter-optin-box' ); ?>[[/read_more_button]]</p>
<p><?php _e( "If that doesn't work, copy and paste the following link in your browser:", 'newsletter-optin-box' ); ?></p>
<p>[[post_url]]</p>
<p><?php _e( 'Cheers,', 'newsletter-optin-box' ); ?></p>
<p>[[post_author]]</p>
