		<!-- footer -->
		<?php if ( ! empty( $permission_text ) ) { ?>
		<table class="footer-wrap" cellpadding="0" cellspacing="0" border="0" align="center">
			<tbody>
				<tr>
					<td></td>
					<td class="container">
						<!-- content -->
							<div class="content">
								<table>
									<tbody>
										<tr>
											<td align="center" valign="top">
												<?php echo $permission_text; ?>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						<!-- /content -->
					</td>
					<td></td>
				</tr>
			</tbody>
		</table>
		<?php } ?>

		<?php if ( ! empty( $footer_text ) ) { ?>
		<table class="footer-wrap" cellpadding="0" cellspacing="0" border="0" align="center">
			<tbody>
				<tr>
					<td></td>
					<td class="container">
						<!-- content -->
							<div class="content">
								<table>
									<tbody>
										<tr>
											<td align="center" valign="top">
												<?php echo $footer_text; ?>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						<!-- /content -->
					</td>
					<td></td>
				</tr>
			</tbody>
		</table>
		<?php } ?>
		<!-- end footer -->

		</td>
      </tr>
    </tbody></table>

</body>
</html>
