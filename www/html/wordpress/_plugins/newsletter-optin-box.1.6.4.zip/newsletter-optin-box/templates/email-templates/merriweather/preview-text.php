<?php if ( ! empty( $preview_text ) ) { ?>
	<!-- start preheader -->
	<div class="preheader" style="display: none; max-width: 0; max-height: 0; overflow: hidden; font-size: 1px; line-height: 1px; color: #fff; opacity: 0;">
		<?php echo $preview_text; ?>
	</div>
	<!-- end preheader -->
<?php } ?>
