<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title><?php echo $title; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow" />
	<?php include plugin_dir_path( __FILE__ ) . 'styles.php'; ?>
</head>
<body>

	<table id="backgroundTable" cellpadding="0" cellspacing="0" border="0">
    	<tbody>
			<tr>
        		<td>
