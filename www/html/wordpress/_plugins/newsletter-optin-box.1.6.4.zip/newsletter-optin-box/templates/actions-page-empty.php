<?php
    echo do_shortcode( '[noptin_action_page]' );
