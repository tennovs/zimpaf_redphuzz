<div class="noptin-subscribers wrap">
	<p>
		<?php _e( 'This subscriber may have been deleted.', 'newsletter-optin-box' ); ?>
	</p>
</div>
